import os
import sys
import json
import time
import requests
import pandas as pd
import yfinance as yf
from datetime import datetime

# บังคับให้ Output Stream รองรับภาษาไทยบน Terminal
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

SECTOR_JSON_PATH = "sp500_sector_groups.json"
CONFIG_PATH = "config.json"
OUTPUT_REPORT_PATH = "sp500_sector_moneyflow_report.md"

def load_sector_groups(json_path: str = SECTOR_JSON_PATH) -> dict:
    if not os.path.exists(json_path):
        print(f"🔴 [ERROR] ไม่พบไฟล์ '{json_path}' กรุณารันสคริปต์จัดกลุ่ม S&P 500 ก่อน")
        sys.exit(1)
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        return data.get("sector_groups", {})

# --- 1. CALCULATE SECTOR METRICS & MONEY FLOW ---
def analyze_sector_money_flow(sector_groups: dict) -> list:
    print("=" * 95)
    print("📊 [STEP 1/2] กำลังดึงข้อมูลราคา ปริมาณการซื้อขาย และคำนวณ Money Flow รายกลุ่ม...")
    print("=" * 95)

    # ดึงข้อมูล Benchmark SPY เพื่อวัด Relative Strength
    spy_pct_change = 0.0
    try:
        spy_df = yf.download("SPY", period="5d", interval="1d", auto_adjust=True, progress=False)
        if not spy_df.empty and len(spy_df) >= 2:
            if isinstance(spy_df.columns, pd.MultiIndex):
                spy_df.columns = spy_df.columns.get_level_values(0)
            spy_close = float(spy_df["Close"].iloc[-1])
            spy_prev = float(spy_df["Close"].iloc[-2])
            spy_pct_change = ((spy_close - spy_prev) / spy_prev) * 100
    except Exception:
        spy_pct_change = 0.0

    sector_results = []

    for sector_name, sub_groups in sector_groups.items():
        all_symbols = []
        for sub_name, stocks in sub_groups.items():
            for s in stocks:
                all_symbols.append(s["symbol"])

        print(f"⏳ Processing: {sector_name:<25} ({len(all_symbols)} tickers)...", end="", flush=True)

        # ดึงราคา 1 เดือนย้อนหลังของหุ้นใน Sector แบบ Batch
        try:
            data = yf.download(all_symbols, period="1mo", interval="1d", auto_adjust=True, progress=False)
            time.sleep(0.2)
        except Exception as e:
            print(f" 🔴 Error: {e}")
            continue

        if data.empty:
            print(" 🟡 No Data")
            continue

        valid_stocks_data = []
        total_dollar_volume = 0.0
        advancing_count = 0
        declining_count = 0

        # วนลูปประมวลผลหุ้นรายตัวในกลุ่ม
        for sym in all_symbols:
            try:
                if len(all_symbols) == 1:
                    df_stock = data.copy()
                else:
                    df_stock = pd.DataFrame({
                        "Open": data["Open"][sym],
                        "High": data["High"][sym],
                        "Low": data["Low"][sym],
                        "Close": data["Close"][sym],
                        "Volume": data["Volume"][sym]
                    }).dropna()

                if len(df_stock) < 10:
                    continue

                close_curr = float(df_stock["Close"].iloc[-1])
                close_prev = float(df_stock["Close"].iloc[-2])
                pct_change = ((close_curr - close_prev) / close_prev) * 100
                
                vol_curr = float(df_stock["Volume"].iloc[-1])
                vol_sma20 = float(df_stock["Volume"].rolling(20).mean().iloc[-1])
                rvol = round(vol_curr / vol_sma20, 2) if vol_sma20 > 0 else 1.0

                dollar_vol = close_curr * vol_curr
                total_dollar_volume += dollar_vol

                # คำนวณ Swing High 60 วัน (หรือจาก Data ที่มี)
                swing_high = float(df_stock["High"].iloc[:-1].max())
                df_stock["EMA20"] = df_stock["Close"].ewm(span=20, adjust=False).mean()
                df_stock["EMA50"] = df_stock["Close"].ewm(span=50, adjust=False).mean()
                
                ema20 = float(df_stock["EMA20"].iloc[-1])
                ema50 = float(df_stock["EMA50"].iloc[-1])

                if pct_change > 0:
                    advancing_count += 1
                else:
                    declining_count += 1

                valid_stocks_data.append({
                    "symbol": sym,
                    "close": close_curr,
                    "pct_change": pct_change,
                    "dollar_volume": dollar_vol,
                    "rvol": rvol,
                    "swing_high": swing_high,
                    "near_breakout": close_curr >= (swing_high * 0.98),
                    "ema_bullish": close_curr > ema20 and ema20 > ema50
                })
            except Exception:
                continue

        if not valid_stocks_data:
            print(" 🟡 Skipped")
            continue

        # คำนวณค่าสถิติมุมมองภาพรวมกลุ่ม
        df_sec = pd.DataFrame(valid_stocks_data)
        min_price = float(df_sec["close"].min())
        max_price = float(df_sec["close"].max())
        avg_price = float(df_sec["close"].mean())
        avg_pct_change = float(df_sec["pct_change"].mean())
        
        # Relative Strength เทียบ SPY
        relative_strength = round(avg_pct_change - spy_pct_change, 2)
        breadth_ratio = (advancing_count / len(valid_stocks_data)) * 100

        # ทิศทางเงินหมุนเวียน (Money Flow Direction)
        if avg_pct_change > 0.5 and breadth_ratio >= 60 and relative_strength > 0:
            money_flow_status = "🟢 MONEY IN (Strong Inflow)"
        elif avg_pct_change > 0 and breadth_ratio >= 50:
            money_flow_status = "🟡 MILD INFLOW (Accumulating)"
        elif avg_pct_change < -0.5 and breadth_ratio < 40:
            money_flow_status = "🔴 MONEY OUT (Outflow/Distribution)"
        else:
            money_flow_status = "⚪ NEUTRAL (Consolidating)"

        # --- MARTIN LUK SECTOR LEADER SELECTION ---
        # 1. สภาพคล่องสูง (Dollar Vol >= $10M)
        # 2. RVOL สูงสุด และทรงกราฟจ่อ Breakout / EMA Bullish
        leaders_df = df_sec[df_sec["dollar_volume"] >= 10000000].sort_values(
            by=["near_breakout", "rvol", "pct_change"], ascending=[False, False, False]
        )

        star_leader = None
        if not leaders_df.empty:
            top_candidate = leaders_df.iloc[0]
            star_leader = {
                "symbol": top_candidate["symbol"],
                "close": round(top_candidate["close"], 2),
                "pct_change": round(top_candidate["pct_change"], 2),
                "rvol": top_candidate["rvol"],
                "dollar_volume_m": round(top_candidate["dollar_volume"] / 1e6, 2),
                "is_breakout": top_candidate["near_breakout"]
            }

        sector_results.append({
            "sector": sector_name,
            "stock_count": len(valid_stocks_data),
            "min_price": round(min_price, 2),
            "max_price": round(max_price, 2),
            "avg_price": round(avg_price, 2),
            "avg_pct_change": round(avg_pct_change, 2),
            "total_dollar_vol_m": round(total_dollar_volume / 1e6, 2),
            "relative_strength": relative_strength,
            "breadth_pct": round(breadth_ratio, 1),
            "money_flow": money_flow_status,
            "star_leader": star_leader
        })

        print(" 🟢 Done")

    return sector_results

# --- 2. GENERATE MARKDOWN REPORT ---
def export_sector_summary_report(sector_results: list):
    print("\n" + "=" * 95)
    print("📝 [STEP 2/2] กำลังสร้างรายงานสรุปผลภาพรวมและดาวเด่นประจำกลุ่ม...")
    print("=" * 95)

    # จัดลำดับกลุ่มอุตสาหกรรมตาม Money Flow & Relative Strength
    sector_results.sort(key=lambda x: (x["relative_strength"], x["avg_pct_change"]), reverse=True)

    md_content = f"""# 📊 S&P 500 Sector Overview & Money Flow Report
**Generated Date:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`  
**Analysis Framework:** Top-Down Sector Rotation & Martin Luk Leader Selection

---

## 🧭 1. ภาพรวมสรุปทิศทางเงินหมุนเวียน (Sector Money Flow Overview)

| กลุ่มอุตสาหกรรม (Sector) | จำนวนหุ้น | Min Price | Max Price | Avg Price | % Change เฉลี่ย | Dollar Volume รวม | RS vs SPY | ทิศทางเงินไหล (Money Flow) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
"""
    for s in sector_results:
        md_content += f"| **{s['sector']}** | {s['stock_count']} | ${s['min_price']} | ${s['max_price']} | ${s['avg_price']} | {s['avg_pct_change']:+.2f}% | ${s['total_dollar_vol_m']:,.1f}M | {s['relative_strength']:+.2f} | {s['money_flow']} |\n"

    md_content += """\n---

## 🌟 2. รายชื่อดาวเด่นประจำกลุ่ม (Martin Luk Sector Leaders)

คัดเลือกเฉพาะหุ้นในแต่ละกลุ่มที่มี **สภาพคล่องสูง (Dollar Vol $\\ge \\$10M/วัน)**, **RVOL เข้าหนาแน่น**, และ **ทรงกราฟจ่อ Breakout/แข็งแกร่งกว่าตลาด**

"""

    for s in sector_results:
        leader = s["star_leader"]
        md_content += f"### 📌 {s['sector']} (ทิศทางเงิน: {s['money_flow']})\n"
        if leader:
            breakout_tag = "🚀 [NEAR BREAKOUT / SWING HIGH]" if leader["is_breakout"] else "📈 [MOMENTUM LEADER]"
            md_content += f"- **ดาวเด่นประจำกลุ่ม:** `{leader['symbol']}` {breakout_tag}\n"
            md_content += f"  - **ราคาล่าสุด:** `${leader['close']}` ({leader['pct_change']:+.2f}%)\n"
            md_content += f"  - **Relative Volume (RVOL):** `{leader['rvol']}x`\n"
            md_content += f"  - **Dollar Volume (สภาพคล่อง):** `${leader['dollar_volume_m']} Million/day`\n"
        else:
            md_content += f"- *ไม่พบหุ้นเข้าเกณฑ์ดาวเด่นที่มีสภาพคล่องเพียงพอในกลุ่มนี้*\n"
        md_content += "\n"

    with open(OUTPUT_REPORT_PATH, "w", encoding="utf-8") as f:
        f.write(md_content)

    print(f"💾 บันทึกรายงานสรุปฉบับสมบูรณ์ลงไฟล์: '{OUTPUT_REPORT_PATH}' เรียบร้อยแล้ว!")

def main():
    sector_groups = load_sector_groups()
    sector_results = analyze_sector_money_flow(sector_groups)
    export_sector_summary_report(sector_results)
    print("\n" + "=" * 95)
    print("🎉 [SUCCESS] การวิเคราะห์ภาพรวมอุตสาหกรรมและค้นหาดาวเด่นเสร็จสมบูรณ์!")
    print("=" * 95)

if __name__ == "__main__":
    main()