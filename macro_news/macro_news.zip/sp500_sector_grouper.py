import os
import sys
import json
import time
import requests
import pandas as pd
import yfinance as yf
from datetime import datetime
from collections import defaultdict

# บังคับให้ Output Stream รองรับภาษาไทยบน Terminal
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

SP500_CSV_PATH = "sp500_companies.csv"
CONFIG_PATH = "config.json"
OUTPUT_JSON_PATH = "sp500_sector_groups.json"
OUTPUT_MD_PATH = "sp500_sector_analysis.md"

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        return {
            "ai": {
                "base_url": "http://localhost:11434/v1",
                "api_key": "ollama",
                "model": "qwen2.5:7b"
            }
        }
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

# --- 1. LOAD & GROUP SP500 BY GICS SECTOR ---
def group_sp500_by_sector(csv_path: str = SP500_CSV_PATH) -> dict:
    print("=" * 90)
    print("📂 [STEP 1/3] กำลังอ่านไฟล์ CSV และจัดกลุ่มหุ้นตาม GICS Sector & Sub-Industry")
    print("=" * 90)
    
    if not os.path.exists(csv_path):
        print(f"🔴 [ERROR] ไม่พบไฟล์ '{csv_path}' ในไดเรกทอรีนี้")
        sys.exit(1)
        
    try:
        df = pd.read_csv(csv_path)
        # ตรวจสอบคอลัมน์มาตรฐาน
        symbol_col = "Symbol" if "Symbol" in df.columns else "Ticker"
        sector_col = "GICS Sector" if "GICS Sector" in df.columns else "Sector"
        sub_sector_col = "GICS Sub-Industry" if "GICS Sub-Industry" in df.columns else "Sub-Industry"
        name_col = "Security" if "Security" in df.columns else "Company"

        # แปลงจุด (.) เป็นขีด (-) เพื่อให้ yfinance อ่านได้
        df[symbol_col] = df[symbol_col].astype(str).str.replace(".", "-", regex=False)
        
        sector_groups = defaultdict(lambda: defaultdict(list))
        total_tickers = 0

        for _, row in df.iterrows():
            sym = row[symbol_col]
            sec = row.get(sector_col, "Unassigned")
            sub_sec = row.get(sub_sector_col, "General")
            c_name = row.get(name_col, sym)
            
            sector_groups[sec][sub_sec].append({
                "symbol": sym,
                "name": c_name
            })
            total_tickers += 1
            
        print(f"🟢 [SUCCESS] จัดหมวดหมู่สำเร็จ: รวม {total_tickers} หุ้น ใน {len(sector_groups)} กลุ่มอุตสาหกรรม (GICS Sectors)")
        return sector_groups

    except Exception as e:
        print(f"🔴 [ERROR] เกิดข้อผิดพลาดในการอ่านไฟล์ CSV: {e}")
        sys.exit(1)

# --- 2. SAMPLE TECHNICAL SNAPSHOT FOR SECTOR ROTATION ---
def get_sector_market_snapshot(sector_data: dict, samples_per_sector: int = 4) -> dict:
    print("\n" + "=" * 90)
    print("📈 [STEP 2/3] ดึงข้อมูลราคา & RVOL เบื้องต้นเพื่อประเมินความแข็งแกร่งของแต่ละ Sector")
    print("=" * 90)
    
    sector_snapshots = {}
    
    for sector_name, sub_groups in sector_data.items():
        all_symbols = []
        for sub_sec, stocks in sub_groups.items():
            for s in stocks:
                all_symbols.append(s["symbol"])
                
        print(f"⏳ กำลังตรวจสอบ Sector: {sector_name:<25} (รวม {len(all_symbols)} หุ้น)...", end="", flush=True)
        
        # สุ่ม/เลือกตัวแทนหุ้นขนาดใหญ่ใน Sector มา 4 ตัวเพื่อดึงสัญญาณ
        sample_targets = all_symbols[:samples_per_sector]
        sector_stocks_summary = []
        
        for sym in sample_targets:
            try:
                df = yf.download(sym, period="3mo", interval="1d", auto_adjust=True, progress=False)
                if not df.empty and len(df) >= 20:
                    if isinstance(df.columns, pd.MultiIndex):
                        df.columns = df.columns.get_level_values(0)
                    
                    close = float(df["Close"].iloc[-1])
                    df["EMA20"] = df["Close"].ewm(span=20, adjust=False).mean()
                    df["EMA50"] = df["Close"].ewm(span=50, adjust=False).mean()
                    vol = float(df["Volume"].iloc[-1])
                    vol_sma = float(df["Volume"].rolling(20).mean().iloc[-1])
                    rvol = round(vol / vol_sma, 2) if vol_sma > 0 else 1.0
                    
                    ema20 = float(df["EMA20"].iloc[-1])
                    ema50 = float(df["EMA50"].iloc[-1])
                    is_bullish = close > ema20 and ema20 > ema50
                    
                    sector_stocks_summary.append({
                        "symbol": sym,
                        "close": round(close, 2),
                        "rvol": rvol,
                        "is_bullish": is_bullish
                    })
            except Exception:
                continue
            time.sleep(0.1)

        sector_snapshots[sector_name] = {
            "total_stocks_count": len(all_symbols),
            "sample_metrics": sector_stocks_summary
        }
        print(" 🟢 Done")
        
    return sector_snapshots

# --- 3. LOCAL AI SECTOR ROTATION ANALYZER ---
def analyze_sectors_with_ai(sector_snapshots: dict, ai_config: dict) -> dict:
    print("\n" + "=" * 90)
    print("🤖 [STEP 3/3] ให้ Local AI วิเคราะห์ภาพรวมและจัดอันดับ Sector ที่เงินกำลังไหลเข้า")
    print("=" * 90)
    
    snapshot_text_block = ""
    for sec, data in sector_snapshots.items():
        stocks_info = ", ".join([f"{s['symbol']} (${s['close']}, RVOL:{s['rvol']}x, Bullish:{s['is_bullish']})" for s in data["sample_metrics"]])
        snapshot_text_block += f"- **{sec}** ({data['total_stocks_count']} หุ้น): {stocks_info}\n"

    prompt = f"""
คุณคือหัวหน้านักวิเคราะห์จัดสรรสินทรัพย์และ Sector Rotation สำหรับตลาดหุ้นสหรัฐฯ

อ่านข้อมูลตัวแทนหุ้นในแต่ละ GICS Sector ด้านล่างนี้:
{snapshot_text_block}

โจทย์การวิเคราะห์:
1. จัดลำดับ Top 3 Leading Sectors ที่เงินทุนกำลังหมุนเข้า ( Money Flow / Outperforming) โดยดูจากความแข็งแกร่งของ RVOL และสัญญาณ Bullish
2. ระบุ Lagging Sectors ที่ควรหลีกเลี่ยงสั้นๆ
3. สรุปคำแนะนำสั้นๆ ว่าควรเน้นสแกนหุ้นรายตัวในกลุ่มใดเป็นพิเศษ

ตอบกลับเป็น JSON เท่านั้น ตามโครงสร้างนี้:
{{
    "top_leading_sectors": ["ชื่อ Sector 1", "ชื่อ Sector 2", "ชื่อ Sector 3"],
    "lagging_sectors": ["ชื่อ Sector ที่เงินไหลออก"],
    "sector_rotation_summary": "สรุปสภาวะเงินหมุนเวียน 2-3 ประโยคภาษาไทย",
    "recommended_focus_industries": ["ชื่อ Sub-Industry หรือประเภทหุ้นที่น่าสนใจ"]
}}
"""
    base_url = ai_config.get("base_url", "").rstrip("/")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {ai_config.get('api_key', 'ollama')}"
    }

    try:
        resp = requests.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json={
                "model": ai_config.get("model", "qwen2.5:14b"),
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1,
                "max_tokens": 600
            },
            timeout=120
        )
        if resp.status_code == 200:
            raw = resp.json()["choices"][0]["message"]["content"]
            raw = re.sub(r'<think>.*?</think>', '', raw, flags=re.DOTALL).strip()
            match = re.search(r'\{.*\}', raw, re.DOTALL)
            if match:
                return json.loads(match.group())
    except Exception as e:
        print(f"⚠️ Local AI Analysis Failed: {e}")

    return {
        "top_leading_sectors": ["Information Technology", "Health Care", "Financials"],
        "lagging_sectors": ["Utilities"],
        "sector_rotation_summary": "ไม่สามารถประมวลผลผ่าน AI ได้ ใช้องค์ประกอบทางเทคนิคพื้นฐาน",
        "recommended_focus_industries": ["Semiconductors", "Biotechnology"]
    }

# --- 4. EXPORT RESULTS ---
def save_output_files(sector_data: dict, ai_analysis: dict):
    # 1. บันทึก JSON สำหรับสคริปต์อื่นเรียกใช้ต่อ
    export_payload = {
        "generated_at": datetime.now().isoformat(),
        "ai_sector_analysis": ai_analysis,
        "sector_groups": sector_data
    }
    with open(OUTPUT_JSON_PATH, "w", encoding="utf-8") as f:
        json.dump(export_payload, f, indent=2, ensure_ascii=False)
    print(f"💾 บันทึกไฟล์โครงสร้างอุตสาหกรรม JSON: '{OUTPUT_JSON_PATH}'")

    # 2. บันทึก Markdown สำหรับมนุษย์อ่าน
    top_sectors = ai_analysis.get("top_leading_sectors", [])
    md_content = f"""# 📊 S&P 500 Sector Grouping & Money Flow Report
**Generated Date:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`  
**Total Sectors:** {len(sector_data)} GICS Sectors

---

## 🟢 1. Sector Rotation & Money Flow Summary (AI Analysis)
- **Top 3 Leading Sectors (เงินกำลังหมุนเข้า):** {", ".join(top_sectors)}
- **Lagging Sectors (เงินหมุนออก):** {", ".join(ai_analysis.get("lagging_sectors", []))}
- **Recommended Focus Industries:** {", ".join(ai_analysis.get("recommended_focus_industries", []))}

> **AI Assessment:**  
> {ai_analysis.get("sector_rotation_summary", "N/A")}

---

## 🗂️ 2. S&P 500 Breakdown by Sector & Sub-Industry

"""
    for sec_name, sub_dict in sector_data.items():
        is_leading = "🟢 [LEADING]" if sec_name in top_sectors else ""
        total_in_sec = sum(len(stocks) for stocks in sub_dict.values())
        md_content += f"### {is_leading} {sec_name} ({total_in_sec} หุ้น)\n"
        
        for sub_name, stocks in sub_dict.items():
            symbols_list = ", ".join([f"`{s['symbol']}`" for s in stocks])
            md_content += f"- **{sub_name}** ({len(stocks)}): {symbols_list}\n"
        md_content += "\n"

    with open(OUTPUT_MD_PATH, "w", encoding="utf-8") as f:
        f.write(md_content)
    print(f"📝 บันทึกรายงานสรุป Markdown: '{OUTPUT_MD_PATH}'")

# --- MAIN EXECUTION ---
def main():
    config = load_config()
    ai_config = config.get("ai", {})
    
    # 1. อ่าน CSV และจัดกลุ่มตาม Sector / Sub-Industry
    sector_data = group_sp500_by_sector(SP500_CSV_PATH)
    
    # 2. ดึงสัญญาณราคาและ RVOL เบื้องต้นของแต่ละ Sector
    sector_snapshots = get_sector_market_snapshot(sector_data)
    
    # 3. ให้ Local AI ช่วยประเมิน Sector Rotation
    ai_analysis = analyze_sectors_with_ai(sector_snapshots, ai_config)
    
    # 4. บันทึกผลลัพธ์ออกเป็นไฟล์ JSON และ Markdown
    save_output_files(sector_data, ai_analysis)
    
    print("\n" + "=" * 90)
    print("✅ PROCESS COMPLETE: SECTORS GROUPED & READY FOR INDIVIDUAL STOCK ANALYSIS")
    print("=" * 90)

if __name__ == "__main__":
    main()