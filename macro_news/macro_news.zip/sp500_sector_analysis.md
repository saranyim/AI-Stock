# 📊 S&P 500 Sector Grouping & Money Flow Report
**Generated Date:** `2026-11-11 11:49:57`  
**Total Sectors:** 11 GICS Sectors

---

## 🟢 1. Sector Rotation & Money Flow Summary (AI Analysis)
- **Top 3 Leading Sectors (เงินกำลังหมุนเข้า):** Information Technology, Health Care, Financials
- **Lagging Sectors (เงินหมุนออก):** Utilities
- **Recommended Focus Industries:** Semiconductors, Biotechnology

> **AI Assessment:**  
> ไม่สามารถประมวลผลผ่าน AI ได้ ใช้องค์ประกอบทางเทคนิคพื้นฐาน

---

## 🗂️ 2. S&P 500 Breakdown by Sector & Sub-Industry

###  Industrials (83 หุ้น)
- **Industrial Conglomerates** (3): `MMM`, `DD`, `HON`
- **Building Products** (7): `AOS`, `ALLE`, `CARR`, `JCI`, `LII`, `MAS`, `TT`
- **Electrical Components & Equipment** (6): `AME`, `BE`, `ETN`, `EMR`, `ROK`, `VRT`
- **Human Resource & Employment Services** (2): `ADP`, `PAYX`
- **Aerospace & Defense** (13): `AXON`, `BA`, `GE`, `GD`, `HONA`, `HWM`, `HII`, `LHX`, `LMT`, `NOC`, `RTX`, `TXT`, `TDG`
- **Data Processing & Outsourced Services** (1): `BR`
- **Air Freight & Logistics** (4): `CHRW`, `EXPD`, `FDX`, `UPS`
- **Construction Machinery & Heavy Transportation Equipment** (4): `CAT`, `CMI`, `PCAR`, `WAB`
- **Diversified Support Services** (3): `CTAS`, `CPRT`, `LDOS`
- **Construction & Engineering** (4): `FIX`, `EME`, `J`, `PWR`
- **Rail Transportation** (3): `CSX`, `NSC`, `UNP`
- **Agricultural & Farm Machinery** (1): `DE`
- **Passenger Airlines** (3): `DAL`, `LUV`, `UAL`
- **Industrial Machinery & Supplies & Components** (14): `DOV`, `FTV`, `HUBB`, `IEX`, `ITW`, `IR`, `NDSN`, `OTIS`, `PH`, `PNR`, `SNA`, `SWK`, `GWW`, `XYL`
- **Research & Consulting Services** (2): `EFX`, `VRSK`
- **Trading Companies & Distributors** (3): `FAST`, `FERG`, `URI`
- **Cargo Ground Transportation** (3): `FDXF`, `JBHT`, `ODFL`
- **Heavy Electrical Equipment** (2): `GEV`, `GNRC`
- **Environmental & Facilities Services** (4): `RSG`, `ROL`, `VLTO`, `WM`
- **Passenger Ground Transportation** (1): `UBER`

### 🟢 [LEADING] Health Care (60 หุ้น)
- **Health Care Equipment** (16): `ABT`, `BAX`, `BDX`, `BSX`, `DXCM`, `EW`, `GEHC`, `IDXX`, `PODD`, `ISRG`, `MDT`, `RMD`, `RVTY`, `STE`, `SYK`, `ZBH`
- **Biotechnology** (8): `ABBV`, `AMGN`, `BIIB`, `GILD`, `INCY`, `MRNA`, `REGN`, `VRTX`
- **Life Sciences Tools & Services** (9): `A`, `TECH`, `CRL`, `DHR`, `ILMN`, `IQV`, `MTD`, `TMO`, `WAT`
- **Health Care Supplies** (3): `ALGN`, `COO`, `WST`
- **Pharmaceuticals** (7): `BMY`, `JNJ`, `LLY`, `MRK`, `PFE`, `VTRS`, `ZTS`
- **Health Care Distributors** (4): `CAH`, `COR`, `HSIC`, `MCK`
- **Managed Health Care** (4): `CNC`, `ELV`, `HUM`, `UNH`
- **Health Care Services** (5): `CI`, `CVS`, `DVA`, `LH`, `DGX`
- **Health Care Facilities** (2): `HCA`, `UHS`
- **Health Care Technology** (2): `SOLV`, `VEEV`

### 🟢 [LEADING] Information Technology (75 หุ้น)
- **IT Consulting & Other Services** (4): `ACN`, `CTSH`, `IT`, `IBM`
- **Application Software** (14): `ADBE`, `ADSK`, `CDNS`, `DDOG`, `FICO`, `INTU`, `ORCL`, `PLTR`, `PTC`, `CRM`, `SNPS`, `TRMB`, `TYL`, `WDAY`
- **Semiconductors** (15): `AMD`, `ADI`, `AVGO`, `FSLR`, `INTC`, `MRVL`, `MCHP`, `MU`, `MPWR`, `NVDA`, `NXPI`, `ON`, `QCOM`, `SWKS`, `TXN`
- **Internet Services & Infrastructure** (3): `AKAM`, `GDDY`, `VRSN`
- **Electronic Components** (3): `APH`, `COHR`, `GLW`
- **Technology Hardware, Storage & Peripherals** (10): `AAPL`, `DELL`, `P`, `HPE`, `HPQ`, `NTAP`, `SNDK`, `STX`, `SMCI`, `WDC`
- **Semiconductor Materials & Equipment** (5): `AMAT`, `KLAC`, `LRCX`, `Q`, `TER`
- **Communications Equipment** (6): `ANET`, `CIEN`, `CSCO`, `FFIV`, `LITE`, `MSI`
- **Technology Distributors** (1): `CDW`
- **Systems Software** (7): `CRWD`, `FTNT`, `GEN`, `MSFT`, `PANW`, `NOW`, `TWLO`
- **Electronic Manufacturing Services** (3): `FLEX`, `JBL`, `TEL`
- **Electronic Equipment & Instruments** (4): `KEYS`, `ROP`, `TDY`, `ZBRA`

###  Utilities (31 หุ้น)
- **Independent Power Producers & Energy Traders** (2): `AES`, `NRG`
- **Electric Utilities** (15): `LNT`, `AEP`, `CEG`, `DUK`, `EIX`, `ETR`, `EVRG`, `ES`, `EXC`, `FE`, `PPL`, `PEG`, `SO`, `VST`, `WEC`
- **Multi-Utilities** (12): `AEE`, `CNP`, `CMS`, `ED`, `D`, `DTE`, `NEE`, `NI`, `PCG`, `PNW`, `SRE`, `XEL`
- **Water Utilities** (1): `AWK`
- **Gas Utilities** (1): `ATO`

### 🟢 [LEADING] Financials (76 หุ้น)
- **Life & Health Insurance** (5): `AFL`, `GL`, `MET`, `PFG`, `PRU`
- **Property & Casualty Insurance** (8): `ALL`, `ACGL`, `CB`, `CINF`, `HIG`, `PGR`, `TRV`, `WRB`
- **Consumer Finance** (3): `AXP`, `COF`, `SYF`
- **Multi-line Insurance** (3): `AIG`, `AIZ`, `L`
- **Asset Management & Custody Banks** (12): `AMP`, `APO`, `ARES`, `BLK`, `BX`, `BNY`, `BEN`, `IVZ`, `KKR`, `NTRS`, `STT`, `TROW`
- **Insurance Brokers** (6): `AON`, `AJG`, `BRO`, `ERIE`, `MRSH`, `WTW`
- **Diversified Banks** (7): `BAC`, `C`, `JPM`, `PNC`, `TFC`, `USB`, `WFC`
- **Multi-Sector Holdings** (1): `BRK-B`
- **Transaction & Payment Processing Services** (9): `XYZ`, `CPAY`, `FIS`, `FISV`, `GPN`, `JKHY`, `MA`, `PYPL`, `V`
- **Financial Exchanges & Data** (9): `CBOE`, `CME`, `COIN`, `FDS`, `ICE`, `MCO`, `MSCI`, `NDAQ`, `SPGI`
- **Investment Banking & Brokerage** (6): `SCHW`, `GS`, `IBKR`, `MS`, `RJF`, `HOOD`
- **Regional Banks** (6): `CFG`, `FITB`, `HBAN`, `KEY`, `MTB`, `RF`
- **Reinsurance** (1): `EG`

###  Materials (24 หุ้น)
- **Industrial Gases** (2): `APD`, `LIN`
- **Specialty Chemicals** (6): `ALB`, `ECL`, `IFF`, `LYB`, `PPG`, `SHW`
- **Paper & Plastic Packaging Products & Materials** (5): `AMCR`, `AVY`, `IP`, `PKG`, `SW`
- **Metal, Glass & Plastic Containers** (1): `BALL`
- **Fertilizers & Agricultural Chemicals** (2): `CF`, `MOS`
- **Construction Materials** (3): `CRH`, `MLM`, `VMC`
- **Commodity Chemicals** (1): `DOW`
- **Copper** (1): `FCX`
- **Gold** (1): `NEM`
- **Steel** (2): `NUE`, `STLD`

###  Consumer Discretionary (47 หุ้น)
- **Hotels, Resorts & Cruise Lines** (8): `ABNB`, `BKNG`, `CCL`, `EXPE`, `HLT`, `MAR`, `NCLH`, `RCL`
- **Broadline Retail** (2): `AMZN`, `EBAY`
- **Automotive Parts & Equipment** (1): `APTV`
- **Automotive Retail** (3): `AZO`, `CVNA`, `ORLY`
- **Computer & Electronics Retail** (1): `BBY`
- **Restaurants** (6): `CMG`, `DRI`, `DPZ`, `MCD`, `SBUX`, `YUM`
- **Footwear** (1): `DECK`
- **Specialized Consumer Services** (1): `DASH`
- **Homebuilding** (4): `DHI`, `LEN`, `NVR`, `PHM`
- **Automobile Manufacturers** (3): `F`, `GM`, `TSLA`
- **Consumer Electronics** (1): `GRMN`
- **Distributors** (1): `GPC`
- **Leisure Products** (1): `HAS`
- **Home Improvement Retail** (2): `HD`, `LOW`
- **Casinos & Gaming** (3): `LVS`, `MGM`, `WYNN`
- **Apparel, Accessories & Luxury Goods** (4): `LULU`, `NKE`, `RL`, `TPR`
- **Apparel Retail** (2): `ROST`, `TJX`
- **Other Specialty Retail** (2): `TSCO`, `ULTA`
- **Homefurnishing Retail** (1): `WSM`

###  Real Estate (30 หุ้น)
- **Office REITs** (2): `ARE`, `BXP`
- **Telecom Tower REITs** (3): `AMT`, `CCI`, `SBAC`
- **Multi-Family Residential REITs** (5): `CPT`, `ESS`, `MAA`, `UDR`, `VMRK`
- **Real Estate Services** (2): `CBRE`, `CSGP`
- **Data Center REITs** (2): `DLR`, `EQIX`
- **Self-Storage REITs** (2): `EXR`, `PSA`
- **Retail REITs** (5): `FRT`, `KIM`, `O`, `REG`, `SPG`
- **Health Care REITs** (3): `DOC`, `VTR`, `WELL`
- **Hotel & Resort REITs** (2): `HST`, `VICI`
- **Single-Family Residential REITs** (1): `INVH`
- **Other Specialized REITs** (1): `IRM`
- **Industrial REITs** (1): `PLD`
- **Timber REITs** (1): `WY`

###  Communication Services (22 หุ้น)
- **Interactive Media & Services** (4): `GOOGL`, `GOOG`, `META`, `RDDT`
- **Advertising** (2): `APP`, `OMC`
- **Integrated Telecommunication Services** (2): `T`, `VZ`
- **Cable & Satellite** (2): `CHTR`, `CMCSA`
- **Wireless Telecommunication Services** (2): `ECHO`, `TMUS`
- **Broadcasting** (2): `FOXA`, `FOX`
- **Movies & Entertainment** (5): `LYV`, `NFLX`, `SKYD`, `TKO`, `DIS`
- **Publishing** (2): `NWSA`, `NWS`
- **Interactive Home Entertainment** (1): `TTWO`

###  Consumer Staples (34 หุ้น)
- **Tobacco** (2): `MO`, `PM`
- **Agricultural Products & Services** (3): `ADM`, `BG`, `VYLR`
- **Distillers & Vintners** (2): `BF-B`, `STZ`
- **Food Retail** (2): `CASY`, `KR`
- **Household Products** (4): `CHD`, `CLX`, `CL`, `KMB`
- **Soft Drinks & Non-alcoholic Beverages** (4): `KO`, `KDP`, `MNST`, `PEP`
- **Consumer Staples Merchandise Retail** (5): `COST`, `DG`, `DLTR`, `TGT`, `WMT`
- **Personal Care Products** (3): `EL`, `KVUE`, `PG`
- **Packaged Foods & Meats** (8): `GIS`, `HSY`, `HRL`, `KHC`, `MKC`, `MDLZ`, `SJM`, `TSN`
- **Food Distributors** (1): `SYY`

###  Energy (21 หุ้น)
- **Oil & Gas Exploration & Production** (9): `APA`, `COP`, `DVN`, `FANG`, `EOG`, `EQT`, `EXE`, `OXY`, `TPL`
- **Oil & Gas Equipment & Services** (3): `BKR`, `HAL`, `SLB`
- **Integrated Oil & Gas** (2): `CVX`, `XOM`
- **Oil & Gas Storage & Transportation** (4): `KMI`, `OKE`, `TRGP`, `WMB`
- **Oil & Gas Refining & Marketing** (3): `MPC`, `PSX`, `VLO`

