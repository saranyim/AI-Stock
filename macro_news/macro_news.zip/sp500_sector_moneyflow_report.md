# 📊 S&P 500 Sector Overview & Money Flow Report
**Generated Date:** `2026-11-11 13:03:44`  
**Analysis Framework:** Top-Down Sector Rotation & Martin Luk Leader Selection

---

## 🧭 1. ภาพรวมสรุปทิศทางเงินหมุนเวียน (Sector Money Flow Overview)

| กลุ่มอุตสาหกรรม (Sector) | จำนวนหุ้น | Min Price | Max Price | Avg Price | % Change เฉลี่ย | Dollar Volume รวม | RS vs SPY | ทิศทางเงินไหล (Money Flow) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| **Energy** | 21 | $31.19 | $389.55 | $142.32 | +0.82% | $14,671.1M | +1.18 | 🟡 MILD INFLOW (Accumulating) |
| **Communication Services** | 22 | $8.04 | $641.39 | $148.8 | +0.52% | $36,745.4M | +0.88 | 🟡 MILD INFLOW (Accumulating) |
| **Financials** | 76 | $15.84 | $1222.15 | $222.47 | +0.51% | $36,566.8M | +0.87 | 🟢 MONEY IN (Strong Inflow) |
| **Consumer Staples** | 33 | $22.21 | $1066.14 | $144.22 | +0.11% | $18,385.7M | +0.48 | 🟡 MILD INFLOW (Accumulating) |
| **Utilities** | 30 | $13.23 | $267.76 | $91.95 | +0.01% | $9,980.1M | +0.38 | 🟡 MILD INFLOW (Accumulating) |
| **Industrials** | 83 | $32.3 | $1472.91 | $294.09 | -0.04% | $41,724.5M | +0.33 | ⚪ NEUTRAL (Consolidating) |
| **Materials** | 24 | $22.99 | $528.21 | $177.31 | -0.09% | $7,644.6M | +0.28 | ⚪ NEUTRAL (Consolidating) |
| **Health Care** | 60 | $20.85 | $1751.38 | $309.49 | -0.15% | $36,066.4M | +0.22 | ⚪ NEUTRAL (Consolidating) |
| **Information Technology** | 75 | $27.79 | $1357.6 | $269.64 | -0.37% | $237,640.1M | -0.00 | ⚪ NEUTRAL (Consolidating) |
| **Real Estate** | 30 | $20.41 | $1050.0 | $142.5 | -0.39% | $7,531.1M | -0.03 | ⚪ NEUTRAL (Consolidating) |
| **Consumer Discretionary** | 47 | $12.28 | $6036.42 | $368.45 | -0.69% | $40,104.6M | -0.32 | 🔴 MONEY OUT (Outflow/Distribution) |

---

## 🌟 2. รายชื่อดาวเด่นประจำกลุ่ม (Martin Luk Sector Leaders)

คัดเลือกเฉพาะหุ้นในแต่ละกลุ่มที่มี **สภาพคล่องสูง (Dollar Vol $\ge \$10M/วัน)**, **RVOL เข้าหนาแน่น**, และ **ทรงกราฟจ่อ Breakout/แข็งแกร่งกว่าตลาด**

### 📌 Energy (ทิศทางเงิน: 🟡 MILD INFLOW (Accumulating))
- **ดาวเด่นประจำกลุ่ม:** `OXY` 📈 [MOMENTUM LEADER]
  - **ราคาล่าสุด:** `$56.9` (+2.04%)
  - **Relative Volume (RVOL):** `1.72x`
  - **Dollar Volume (สภาพคล่อง):** `$954.51 Million/day`

### 📌 Communication Services (ทิศทางเงิน: 🟡 MILD INFLOW (Accumulating))
- **ดาวเด่นประจำกลุ่ม:** `TTWO` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$224.64` (+8.31%)
  - **Relative Volume (RVOL):** `2.71x`
  - **Dollar Volume (สภาพคล่อง):** `$1894.57 Million/day`

### 📌 Financials (ทิศทางเงิน: 🟢 MONEY IN (Strong Inflow))
- **ดาวเด่นประจำกลุ่ม:** `AIZ` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$322.16` (+1.56%)
  - **Relative Volume (RVOL):** `1.46x`
  - **Dollar Volume (สภาพคล่อง):** `$199.71 Million/day`

### 📌 Consumer Staples (ทิศทางเงิน: 🟡 MILD INFLOW (Accumulating))
- **ดาวเด่นประจำกลุ่ม:** `CLX` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$106.6` (+1.01%)
  - **Relative Volume (RVOL):** `2.97x`
  - **Dollar Volume (สภาพคล่อง):** `$1028.6 Million/day`

### 📌 Utilities (ทิศทางเงิน: 🟡 MILD INFLOW (Accumulating))
- **ดาวเด่นประจำกลุ่ม:** `FE` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$46.48` (-0.30%)
  - **Relative Volume (RVOL):** `1.12x`
  - **Dollar Volume (สภาพคล่อง):** `$258.3 Million/day`

### 📌 Industrials (ทิศทางเงิน: ⚪ NEUTRAL (Consolidating))
- **ดาวเด่นประจำกลุ่ม:** `TDG` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$1225.54` (+0.55%)
  - **Relative Volume (RVOL):** `1.54x`
  - **Dollar Volume (สภาพคล่อง):** `$740.1 Million/day`

### 📌 Materials (ทิศทางเงิน: ⚪ NEUTRAL (Consolidating))
- **ดาวเด่นประจำกลุ่ม:** `CF` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$122.36` (+2.58%)
  - **Relative Volume (RVOL):** `1.2x`
  - **Dollar Volume (สภาพคล่อง):** `$328.66 Million/day`

### 📌 Health Care (ทิศทางเงิน: ⚪ NEUTRAL (Consolidating))
- **ดาวเด่นประจำกลุ่ม:** `ALGN` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$174.26` (+0.00%)
  - **Relative Volume (RVOL):** `1.58x`
  - **Dollar Volume (สภาพคล่อง):** `$332.56 Million/day`

### 📌 Information Technology (ทิศทางเงิน: ⚪ NEUTRAL (Consolidating))
- **ดาวเด่นประจำกลุ่ม:** `PTC` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$196.55` (+0.35%)
  - **Relative Volume (RVOL):** `0.88x`
  - **Dollar Volume (สภาพคล่อง):** `$373.39 Million/day`

### 📌 Real Estate (ทิศทางเงิน: ⚪ NEUTRAL (Consolidating))
- **ดาวเด่นประจำกลุ่ม:** `VMRK` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$65.75` (-0.59%)
  - **Relative Volume (RVOL):** `1.85x`
  - **Dollar Volume (สภาพคล่อง):** `$601.25 Million/day`

### 📌 Consumer Discretionary (ทิศทางเงิน: 🔴 MONEY OUT (Outflow/Distribution))
- **ดาวเด่นประจำกลุ่ม:** `WYNN` 🚀 [NEAR BREAKOUT / SWING HIGH]
  - **ราคาล่าสุด:** `$87.3` (+0.69%)
  - **Relative Volume (RVOL):** `1.13x`
  - **Dollar Volume (สภาพคล่อง):** `$258.25 Million/day`

