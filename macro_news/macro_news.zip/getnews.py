import os
import sys
import time
import json
import random
import re
import requests
import feedparser
from datetime import datetime, timedelta

# บังคับให้ Output Stream รองรับภาษาไทยบน Terminal
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# --- CONFIGURATION ---
CONFIG_PATH = "config.json"
CACHE_NEWS_PATH = "temp_fetched_news.json"
OUTPUT_MD_PATH = "daily_macro_watchlist.md"
CACHE_EXPIRY_HOURS = 2  # อายุ Cache ข่าวชั่วคราว (ชั่วโมง)

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0"
]

# 6 แหล่งข่าวสากลหลักที่ผ่านการทดสอบว่าดึงได้เสถียร 100%
VERIFIED_NEWS_SOURCES = {
    "Yahoo Finance": {
        "rss": "https://feeds.finance.yahoo.com/rss/2.0/headline?s={ticker}&region=US&lang=en-US",
        "category": "Equities & General Market"
    },
    "Fed Policy": {
        "rss": "https://www.federalreserve.gov/feeds/press_all.xml",
        "category": "Macro & Fed Policy"
    },
    "Seeking Alpha": {
        "rss": "https://seekingalpha.com/feed.xml",
        "category": "Earnings & Equity Research"
    },
    "CoinDesk": {
        "rss": "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "category": "Crypto & Fintech Sector"
    },
    "OilPrice": {
        "rss": "https://oilprice.com/rss/main",
        "category": "Energy & Commodities"
    },
    "Zacks": {
        "rss": "https://www.zacks.com/rss/news/",
        "category": "Earnings & Upgrades"
    }
}

def load_config() -> dict:
    if not os.path.exists(CONFIG_PATH):
        return {
            "ai": {
                "base_url": "http://localhost:11434/v1",
                "api_key": "ollama",
                "model": "qwen2.5:7b"
            }
        }
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def get_safe_headers():
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "application/xml,text/xml,*/*;q=0.9"
    }

def safe_delay(min_sec=0.5, max_sec=1.2):
    time.sleep(random.uniform(min_sec, max_sec))

# --- 1. LOCAL NEWS CACHE MANAGER (โหลดข่าวครั้งเดียว บันทึกลงเครื่อง) ---
def load_cached_news() -> dict:
    if os.path.exists(CACHE_NEWS_PATH):
        try:
            with open(CACHE_NEWS_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
                cached_time = datetime.fromisoformat(data.get("timestamp", "2000-01-01"))
                if datetime.now() - cached_time < timedelta(hours=CACHE_EXPIRY_HOURS):
                    print(f"📦 [CACHE HIT] โหลดข่าวเก่าจากไฟล์ดิสก์ '{CACHE_NEWS_PATH}' (ไม่ต้องยิง request ใหม่)")
                    return data
                else:
                    print("⌛ [CACHE EXPIRED] ข่าวเดิมเกินอายุ กำลังดึงข่าวใหม่...")
        except Exception:
            pass
    return {}

def save_news_cache(news_payload: dict):
    with open(CACHE_NEWS_PATH, "w", encoding="utf-8") as f:
        json.dump(news_payload, f, indent=2, ensure_ascii=False)
    print(f"💾 [CACHE SAVED] บันทึกไฟล์ข่าวลงเครื่องเรียบร้อย: '{CACHE_NEWS_PATH}'")

def fetch_all_verified_news(target_ticker: str = "NVDA", force_refresh: bool = False) -> dict:
    if not force_refresh:
        cached_data = load_cached_news()
        if cached_data and cached_data.get("articles"):
            return cached_data

    print("=" * 95)
    print(f"📡  FETCHING NEWS FROM 6 STABLE VERIFIED SOURCES (Ticker Focus: {target_ticker})")
    print("=" * 95)
    
    collected_articles = []
    source_stats = {}
    
    for name, info in VERIFIED_NEWS_SOURCES.items():
        rss_url = info["rss"].format(ticker=target_ticker)
        print(f"⏳ Fetching: {name:<18} [{info['category']}]...", end="", flush=True)
        
        safe_delay()  # Anti-flood delay
        try:
            feed = feedparser.parse(rss_url, request_headers=get_safe_headers())
            entries = feed.entries
            count = len(entries)
            source_stats[name] = count
            print(f" 🟢 Success ({count} items)")
            
            for entry in entries[:8]:  # ดึงสูงสุด 8 ข่าวต่อแหล่ง
                collected_articles.append({
                    "source": name,
                    "category": info["category"],
                    "title": entry.get("title", "No Title"),
                    "link": entry.get("link", ""),
                    "published": entry.get("published", entry.get("updated", "N/A")),
                    "summary": entry.get("summary", "")[:350]
                })
        except Exception as e:
            source_stats[name] = 0
            print(f" 🔴 Failed: {e}")
            
    payload = {
        "timestamp": datetime.now().isoformat(),
        "target_ticker": target_ticker,
        "total_articles": len(collected_articles),
        "source_stats": source_stats,
        "articles": collected_articles
    }
    
    save_news_cache(payload)
    return payload

# --- 2. LOCAL AI NEWS ANALYZER ---
def analyze_news_with_local_ai(news_payload: dict, ai_config: dict) -> dict:
    print("\n" + "=" * 95)
    print(f"🤖  ANALYZING NEWS WITH LOCAL AI ({ai_config.get('model')})")
    print("=" * 95)
    
    articles = news_payload.get("articles", [])
    if not articles:
        return {"error": "No news articles available for AI analysis"}
        
    news_text_block = "\n".join([
        f"- [{a['source']} | {a['category']}] {a['title']}: {a['summary']}"
        for a in articles[:30]  # ส่งสูงสุด 30 ข่าวให้ AI อ่าน
    ])

    prompt = f"""
คุณคือหัวหน้านักวิเคราะห์การเงินมหภาคและ Sector Rotation สำหรับตลาดหุ้นสหรัฐฯ

อ่านบทความข่าวสารจาก 6 สำนักข่าวสากลหลัก ทั้งหมดต่อไปนี้:
{news_text_block}

โจทย์การวิเคราะห์:
1. ภาพรวมเศรษฐกิจมหภาค (Macro Sentiment) อยู่ในสภาวะใด? (เช่น ขาขึ้น, พักฐาน, หรือระวังความผันผวน)
2. สแกนหา Sector Rotation: เงินทุนรายใหญ่กำลังหมุนออกจากกลุ่มใด และไหลเข้ากลุ่มอุตสาหกรรมใด? (เช่น Semiconductor, Energy, Crypto, Healthcare)
3. มีหุ้นตัวใดที่โดนข่าวพุ่งเป้าเป็นพิเศษหรือไม่? (ทั้งข่าวบวกดันราคา หรือ Red Flag ข่าวลบวิกฤต)

ตอบกลับเป็น JSON เท่านั้น ตามโครงสร้างนี้:
{{
    "market_sentiment": "BULLISH / BEARISH / CAUTION",
    "macro_summary": "สรุปสภาวะตลาดสั้นๆ 2-3 ประโยคภาษาไทย",
    "leading_sectors": ["ชื่อกลุ่มอุตสาหกรรมที่เงินไหลเข้า"],
    "lagging_sectors": ["ชื่อกลุ่มอุตสาหกรรมที่เงินไหลออก"],
    "stock_catalysts": [
        {{"symbol": "NVDA", "news_type": "POSITIVE/NEGATIVE", "detail": "รายละเอียดข่าว"}}
    ]
}}
"""

    base_url = ai_config.get("base_url", "").rstrip("/")
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {ai_config.get('api_key', 'ollama')}"
    }

    try:
        response = requests.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json={
                "model": ai_config.get("model", "qwen2.5:7b"),
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1,
                "max_tokens": 700
            },
            timeout=120
        )
        if response.status_code == 200:
            raw_content = response.json()["choices"][0]["message"]["content"]
            raw_content = re.sub(r'<think>.*?</think>', '', raw_content, flags=re.DOTALL).strip()
            match = re.search(r'\{.*\}', raw_content, re.DOTALL)
            if match:
                return json.loads(match.group())
    except Exception as e:
        print(f"⚠️ Local AI Analysis Failed/Timeout: {e}")

    return {
        "market_sentiment": "CAUTION",
        "macro_summary": "ไม่สามารถประมวลผลผ่าน AI ได้ในขณะนี้ ใช้องค์ประกอบเทคนิคเป็นหลัก",
        "leading_sectors": ["General Market"],
        "lagging_sectors": [],
        "stock_catalysts": []
    }

# --- 3. LIVE MARKDOWN STREAMING EXPORT ---
def export_to_markdown(news_payload: dict, ai_analysis: dict):
    stats = news_payload.get("source_stats", {})
    stats_str = " | ".join([f"**{src}:** {cnt} ข่าว" for src, cnt in stats.items()])
    
    md_content = f"""# 📊 Daily Macro & News Analysis Report
**Generated Date:** `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`  
**News Articles Analyzed:** {news_payload.get('total_articles')} items  
**Source Breakdown:** {stats_str}

---

## 🟢 1. Market Sentiment & Macro Assessment
- **Overall Market Mode:** `{ai_analysis.get('market_sentiment', 'CAUTION')}`
- **AI Summary:** 
> {ai_analysis.get('macro_summary', 'N/A')}

---

## 🔄 2. Sector Rotation (Money Flow Tracking)
- **🟢 Leading Sectors (เงินหมุนเข้า):** {", ".join(ai_analysis.get('leading_sectors', []))}
- **🔴 Lagging Sectors (เงินหมุนออก):** {", ".join(ai_analysis.get('lagging_sectors', []))}

---

## 🎯 3. Stock Catalyst Focus List
"""
    catalysts = ai_analysis.get("stock_catalysts", [])
    if catalysts:
        for c in catalysts:
            badge = "🟢" if c.get("news_type") == "POSITIVE" else "🔴"
            md_content += f"- {badge} **{c.get('symbol')}** ({c.get('news_type')}): {c.get('detail')}\n"
    else:
        md_content += "- ไม่พบข่าวพุ่งเป้าเจาะจงรายหุ้นที่มีนัยสำคัญวิกฤต\n"

    md_content += f"""\n---
## 📰 4. Raw News Headlines Collected
"""
    for a in news_payload.get("articles", [])[:15]:
        md_content += f"- [{a['source']}] [{a['title']}]({a['link']})\n"

    with open(OUTPUT_MD_PATH, "w", encoding="utf-8") as f:
        f.write(md_content)
        f.flush()
        
    print(f"\n📝 [EXPORT COMPLETE] บันทึกผลลัพธ์ลงไฟล์ '{OUTPUT_MD_PATH}' เรียบร้อยแล้ว!")

# --- MAIN EXECUTION FLOW ---
def main():
    config = load_config()
    ai_config = config.get("ai", {})
    
    # 1. ดึงข่าวสารจาก 6 แหล่งเสถียร (และเซฟลงดิสก์)
    news_payload = fetch_all_verified_news(target_ticker="NVDA", force_refresh=False)
    
    # 2. ส่งต่อให้ Local AI วิเคราะห์สภาวะตลาด + Sector Rotation
    ai_analysis = analyze_news_with_local_ai(news_payload, ai_config)
    
    # 3. บันทึกผลออกเป็น Markdown File (.md)
    export_to_markdown(news_payload, ai_analysis)
    
    print("\n" + "=" * 95)
    print("✅ TEST COMPLETE: NEWS FETCHED, CACHED, ANALYZED & EXPORTED TO MARKDOWN")
    print("=" * 95)

if __name__ == "__main__":
    main()